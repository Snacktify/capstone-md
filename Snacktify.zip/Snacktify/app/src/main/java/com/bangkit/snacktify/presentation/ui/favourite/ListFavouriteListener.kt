package com.bangkit.snacktify.presentation.ui.favourite

import com.bangkit.snacktify.presentation.ui.Favourite

interface ListFavouriteListener {

	fun onClick(favourite: Favourite)

}
