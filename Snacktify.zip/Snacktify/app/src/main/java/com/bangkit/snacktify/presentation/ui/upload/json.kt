package com.bangkit.snacktify.presentation.ui.upload

class json {
}