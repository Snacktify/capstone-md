package com.bangkit.snacktify.presentation.ui.detailprofile

import com.bangkit.snacktify.presentation.ui.Itenarary

interface CardClickListener {

	fun onClick(itenarary: Itenarary)
}
