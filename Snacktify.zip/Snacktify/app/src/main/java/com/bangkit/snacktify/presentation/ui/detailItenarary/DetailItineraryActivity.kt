package com.bangkit.snacktify.presentation.ui.detailItenarary

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bangkit.snacktify.R

class DetailItineraryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_itinerary)
    }
}