package com.bangkit.snacktify.presentation.ui.upload

data class jsonItem(
    val address: String,
    val description: String,
    val destination_name: String,
    val id: Int,
    val latitude: String,
    val longitude: String,
    val operational_time: String,
    val phone_number: String
)