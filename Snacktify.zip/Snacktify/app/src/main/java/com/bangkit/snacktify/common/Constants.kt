package com.bangkit.snacktify.common

object Constants {
}